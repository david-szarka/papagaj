# papagaj_v1.0.6

#This software record manipulation with mouse and keyboard.<br>
#You can replay record multiple times and run it faster or slower.<br>
#There is option make screenshot before start Recording.<br>
#Then you can see it when choose Play with screenshot.<br>
#During recording and playing:<br>
#    For pause(or continue) press Right Ctrl.<br>
#    For stop press pause(Right Ctrl), then press Right ALT.<br>
#Take care to set same keyboard language(layout)<br>
#on start Play as it was set on start of Record.<br>
#Records have extension .ppgj<br>